/*
 * Config_Phobos.h
 *
 *  Created on: Mai 08, 2022
 *      Author: Sébastien BOHN
 */

#ifndef INC_CONFIG_H_
#define INC_CONFIG_H_

#include "main.h"
#include "tiroirs.h"
#include "ascenseur.h"
#include "gestion_mouvements.h"
#include "AX12.h"


/*
 * Signification de la donnée arrivant sur l'UART :
 * Entrée sur 8 bits : 87654321
 *
 *        Bits 7 et 8 :
 *        00 : demande de stockage
 *        11 : demande de déstockage
 *
 *        Bits 5 et 6 : Endroit concerné (implique d'autres réglages : hauteur, angle ascenseur etc)
 *        00 : sol (random position)
 *        01 : musée
 *        10 : support hexagones penchés
 *        11 : support hexagones plats mais en hauteur (abri de chantier + support haut)
 *
 *		  Bit 4 :
 *        0 : il ne faut pas garder l'hexagone sur le bras de l'ascenseur
 *        1 : il faut le garder sur le bras de l'ascenseur
 *
 *        Bit 3 :
 *        0 : il ne faut pas retourner l'hexagone
 *        1 : il faut le retourner
 *
 *        Bits 1 et 2 : Couleur de l'hexagone qu'on dépose/ que l'on veut récupérer
 *        00 : brun
 *        01 : rouge
 *        10 : vert
 *        11 : bleu
 *
 *		  NB : le bit 7 reste disponible si besoin d'une info supplémentaire
 */
#define UART_NB_DATA 8


//Angles possibles de l'ascenseur
#define ANGLE_MIN 60
#define ANGLE_MAX 240
#define ANGLE_DROIT 150
#define ANGLE_MUSEE 120 //A vérifier
#define ANGLE_BAC_ECHANTILLON 120//A vérifier, pas sûr du tout!


//Hauteurs des casiers, auxquelles l'ascenseur doit s'arrêter
// Bas => l'ascenseur prend par le dessous, Haut=>l'ascenseur prend par le dessus
#define ASC_LVL_C1_HAUT 70
#define ASC_LVL_C2_BAS 70
#define ASC_LVL_C2_HAUT 70
#define ASC_LVL_C3_BAS 70
#define ASC_LVL_C3_HAUT 70
#define ASC_LVL_C4_BAS 70
#define ASC_LVL_C4_HAUT 70
#define ASC_LVL_C5_BAS 70
#define ASC_LVL_C6_BAS 70
//Hauteurs de l'ascenseur pour les différents emplacements sur le terrain
#define ASC_LVL_KEEP 0
#define ASC_LVL_SOL 0
#define ASC_LVL_MUSEE 0
#define ASC_LVL_BAC_ECHANTILLON 0
#define ASC_LVL_SUPPORT_ECHANTILLON_HAUT_PLAT 0


// Configuration ascenseur
#define POULIE_RADIUS  5 //Valeur en mm
#define TIM15_CST_TEMPS 0.001
#define K_VITESSE 300 //vitesse en mm/s
#define DELTA 5 //Ecart avec la position souhaitée
//Timer 6 pour mettre à jour la vitesse de l'ascenseur, réglé toutes les 2ms.



//Définition d'une structure pour stocker la demande reçue de la carte base roulante
typedef struct
{	uint8_t state; //0=stocker, 1=destocker
	uint8_t place; //donnée sur 2 bits qui spécifie l'endroit
	uint8_t keep; //0=on stocke, 1=on garde sur le bras
	uint8_t reverse; //1=on retourne, 0 sinon
	uint8_t color; //00=brun, 01=rouge, 10=vert, 11=bleu
}Demande_recue;


//Définition d'une structure pour définir les réglages de tous les actionneurs
typedef struct
{	uint16_t AX12_angle_recuperation; 	//Angle de l'AX12 lorsqu'on récupère l'hexagone (dans casier ou sur la table)
	uint16_t AX12_angle_depot; 			//Angle de l'AX12 lorsqu'on dépose/relache l'hexagone
	uint16_t ASC_hauteur_recuperation; 	//Hauteur de l'ascenseur lorsqu'on récupère l'hexagone (dans casier ou sur la table)
	uint16_t ASC_hauteur_depot; 		//Hauteur de l'ascenseur lorsqu'on dépose/relache l'hexagone
	uint8_t casier_concerned;			//Casier concerné par la requête
}Settings_Actionneurs;


//Fonctions utilisées
void configMainFunction();
void configSetStructParameters();
void configSetActionneurCasier();
void configSetActionneurAX12();
void configSetActionneurAscenseur();

#endif /* INC_CONFIG_H_ */
