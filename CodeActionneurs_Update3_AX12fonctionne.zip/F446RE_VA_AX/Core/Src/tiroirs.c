/*
 * Fichier créé par Sébastien BOHN pour Ares
 * Le 21/02/2022
 */


/* Includes ------------------------------------------------------------------*/
#include "tiroirs.h"

/*Variables globales ---------------------------------------------------------*/
MccTiroir_InitTypeDef Mcc1 = {0};
MccTiroir_InitTypeDef Mcc2 = {0};
MccTiroir_InitTypeDef Mcc3 = {0};
MccTiroir_InitTypeDef Mcc4 = {0};
MccTiroir_InitTypeDef Mcc5 = {0};
MccTiroir_InitTypeDef Mcc6 = {0};

extern Settings_Actionneurs settingsActionneurs;
MccTiroir_InitTypeDef MccUsed = {0};

/*Fonctions ------------------------------------------------------------------*/

void tiroir_Init(MccTiroir_InitTypeDef* Mcc, uint8_t numero, GPIO_TypeDef* Input1_Port, uint32_t Input1_Pin,
		GPIO_TypeDef* Input2_Port, uint32_t Input2_Pin, GPIO_TypeDef* Enable_Port, uint32_t Enable_Pin)
{
	Mcc->Input1_Port = Input1_Port;
	Mcc->Input1_Pin = Input1_Pin;
	Mcc->Input2_Port = Input2_Port;
	Mcc->Input2_Pin = Input2_Pin;
	Mcc->Enable_Port = Enable_Port;
	Mcc->Enable_Pin = Enable_Pin;
	Mcc->color = 0;
	Mcc->etat = 0;
	Mcc->identifier = numero;
}

void tiroirs_Init_All(void){
	//Tiroir 1
	tiroir_Init(&Mcc1, 1, M1_IN1_GPIO_Port, M1_IN1_Pin, M1_IN2_GPIO_Port, M1_IN2_Pin, M1_EN_GPIO_Port,
			M1_EN_Pin);
	//Tiroir 2
	tiroir_Init(&Mcc2, 2, M2_IN1_GPIO_Port, M2_IN1_Pin, M2_IN2_GPIO_Port, M2_IN2_Pin, M2_EN_GPIO_Port,
			M2_EN_Pin);
	//Tiroir 3
	tiroir_Init(&Mcc3, 3, M3_IN1_GPIO_Port, M3_IN1_Pin, M3_IN2_GPIO_Port, M3_IN2_Pin, M3_EN_GPIO_Port,
			M3_EN_Pin);
	//Tiroir 4
	tiroir_Init(&Mcc4, 4,  M4_IN1_GPIO_Port, M4_IN1_Pin, M4_IN2_GPIO_Port, M4_IN2_Pin, M4_EN_GPIO_Port,
			M4_EN_Pin);
	//Tiroir 5
	tiroir_Init(&Mcc5, 5, M5_IN1_GPIO_Port, M5_IN1_Pin, M5_IN2_GPIO_Port, M5_IN2_Pin, M5_EN_GPIO_Port,
			M5_EN_Pin);
	//Tiroir 6
	tiroir_Init(&Mcc6, 6, M6_IN1_GPIO_Port, M6_IN1_Pin, M6_IN2_GPIO_Port, M6_IN2_Pin, M6_EN_GPIO_Port,
			M6_EN_Pin);
}

void tiroirArret(MccTiroir_InitTypeDef* Mcc){
	HAL_GPIO_WritePin(Mcc->Input1_Port, Mcc->Input1_Pin, RESET);
	HAL_GPIO_WritePin(Mcc->Input2_Port, Mcc->Input2_Pin, RESET);
}

void tiroirArretAll(){
	//Arrêt de tous les moteurs MCC
	tiroirArret(&Mcc1);
	tiroirArret(&Mcc2);
	tiroirArret(&Mcc3);
	tiroirArret(&Mcc4);
	tiroirArret(&Mcc5);
	tiroirArret(&Mcc6);
}

void tiroirOuvrir(MccTiroir_InitTypeDef* Mcc){
	HAL_GPIO_WritePin(Mcc->Input1_Port, Mcc->Input1_Pin, SET);
}

void tiroirFermer(MccTiroir_InitTypeDef* Mcc){
	HAL_GPIO_WritePin(Mcc->Input2_Port, Mcc->Input2_Pin, SET);
}

void tiroirEnable(MccTiroir_InitTypeDef* Mcc){
	HAL_GPIO_WritePin(Mcc->Enable_Port, Mcc->Enable_Pin, SET);
}

void tiroirEnableAll(){
	//Enable de tous les moteurs pour que les casiers fonctionnent
	tiroirEnable(&Mcc1);
	tiroirEnable(&Mcc2);
	tiroirEnable(&Mcc3);
	tiroirEnable(&Mcc4);
	tiroirEnable(&Mcc5);
	tiroirEnable(&Mcc6);
}

void tiroirDisable(MccTiroir_InitTypeDef* Mcc){
	HAL_GPIO_WritePin(Mcc->Enable_Port, Mcc->Enable_Pin, RESET);
}

void tiroirDisableAll(){
	//Disable de tous les moteurs pour que les casiers ne fonctionnent plus
	tiroirDisable(&Mcc1);
	tiroirDisable(&Mcc2);
	tiroirDisable(&Mcc3);
	tiroirDisable(&Mcc4);
	tiroirDisable(&Mcc5);
	tiroirDisable(&Mcc6);
}

void tiroirSetEmpty(MccTiroir_InitTypeDef* Mcc){
	Mcc->etat = 0;
	Mcc->color = 4; //4=pas de couleur car s'arrête à 3=bleu
}

void tiroirSetOccupied(MccTiroir_InitTypeDef* Mcc, uint8_t color){
	Mcc->etat = 1;
	Mcc->color = color;
}


//Renvoie le numéro de casier disponible, ou 0 si pas de casier disponible
uint8_t tiroirSearchAvailable(uint8_t reverse){
	//Chercher un casier de libre dans le robot
	if(reverse==1){
		//Chercher entre casiers 2 et 4 car seuls ceux-là permettent de retourner un palais
		if(Mcc2.etat==0)
			return 2;
		else if(Mcc3.etat==0)
			return 3;
		else if(Mcc4.etat==0)
			return 4;
	}
	/*
	 * Chercher entre casiers 1,5 et 6
	 * Pas de ELSE comme ça si 2,3ou4 pas dispo, cherche quand même dans les autres
	 */
	if(Mcc1.etat==0)
		return 1;
	else if(Mcc5.etat==0)
		return 5;
	else if(Mcc6.etat==0)
		return 6;
	else
		return 0;
}

//Renvoie le premier casier qui contient la couleur color, 0 si aucun casier ne possède cette couleur
uint8_t tiroirSearchSpecificColor(uint8_t color){
	if(Mcc1.color==color)
		return 1;
	else if(Mcc2.color==color)
		return 2;
	else if(Mcc3.color==color)
		return 3;
	else if(Mcc4.color==color)
		return 4;
	else if(Mcc5.color==color)
		return 5;
	else if(Mcc6.color==color)
		return 6;
	else
		return 0;
}


void tiroirSetUsed(void){
	switch(settingsActionneurs.casier_concerned){
	case 1:
		MccUsed = Mcc1;
		break;
	case 2:
		MccUsed = Mcc2;
		break;
	case 3:
		MccUsed = Mcc3;
		break;
	case 4:
		MccUsed = Mcc4;
		break;
	case 5:
		MccUsed = Mcc5;
		break;
	case 6:
		MccUsed = Mcc6;
		break;
	default:
		break;
	}
}




