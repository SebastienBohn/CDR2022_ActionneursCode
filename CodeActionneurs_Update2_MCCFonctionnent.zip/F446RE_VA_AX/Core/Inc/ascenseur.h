/*
 * ascenseur.h
 *
 *  Created on: Mar 08, 2022
 *      Author: Sébastien BOHN
 */

#ifndef INC_ASCENSEUR_H_
#define INC_ASCENSEUR_H_

#include "main.h"
#include "drv8825.h"
#include <math.h>
#include <stdio.h>
#include "AX12.h"
#include "Config_Phobos.h"

//Définition d'une structure pour l'ascenseur
typedef struct {
	float speed;					// Vitesse de l'ascenseur (en mm/s)
	float position;					// Position de l'ascenseur (en mm) : 0=position basse , 300=position haute
	float position_souhaitee;       // Position que l'on souhaite atteindre
} Ascenseur;


//Fonctions créées
void ascenseur_AX12_init();
void ascenseur_init();
void ascenseur_enableMotor();
void ascenseur_disableMotor();
void ascenseur_setSpeed(float vitesse);
void ascenseur_updatePosition(float dt);
void ascenseur_setPosition(float position);


#endif /* INC_ASCENSEUR_H_ */

