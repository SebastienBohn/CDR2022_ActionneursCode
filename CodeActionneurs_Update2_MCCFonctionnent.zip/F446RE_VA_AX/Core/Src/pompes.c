/*
 * Fichier créé par Sébastien BOHN pour Ares
 * Le 07/03/2022
 */


/* Includes ------------------------------------------------------------------*/
#include "pompes.h"

/*Variables globales ---------------------------------------------------------*/
Pompe_InitTypeDef Pompe1 = {0};
//Pompe_InitTypeDef Pompe2 = {0};
//Pompe_InitTypeDef Pompe3 = {0};

/*Fonctions ------------------------------------------------------------------*/

void pompes_Init(void){
	//Pompe 1
	Pompe1.Pompe_Enable_Port = POMPE1_GPIO_Port;
	Pompe1.Pompe_Enable_Pin = POMPE1_Pin;

	/*
	//Pompe 2
	Pompe2.Pompe_Enable_Port = POMPE2_GPIO_Port;
	Pompe2.Pompe_Enable_Pin = POMPE2_Pin;

	//Pompe 3
	Pompe3.Pompe_Enable_Port = POMPE3_GPIO_Port;
	Pompe3.Pompe_Enable_Pin = POMPE3_Pin;
	*/
}

void pompeEnable(Pompe_InitTypeDef* Pompe){
	HAL_GPIO_WritePin(Pompe->Pompe_Enable_Port, Pompe->Pompe_Enable_Pin, SET);
}

void pompeDisable(Pompe_InitTypeDef* Pompe){
	HAL_GPIO_WritePin(Pompe->Pompe_Enable_Port, Pompe->Pompe_Enable_Pin, RESET);
}


