/*
 * File created by Sébastien BOHN
 * For Ares-CDR2022
 * On 11/05/2022
 */

#include "gestion_mouvements.h"

extern Demande_recue demandeRecue;
extern Settings_Actionneurs settingsActionneurs;
extern Pompe_InitTypeDef Pompe1;
extern MccTiroir_InitTypeDef MccUsed;
extern AX12 ax12;
extern Ascenseur ascenseur;

void mvtMainFunction(){
	if(demandeRecue.state==0){
		mvt_deroulement_stockage();
	}
	else{
		mvt_deroulement_destockage();
	}
}


void mvt_deroulement_stockage(){
	ascenseur_setPosition(settingsActionneurs.ASC_hauteur_recuperation+20);//+20 car hauteur en mm
	while(ascenseur.position!=ascenseur.position_souhaitee){/*Do nothing*/}
	AX12_setPosition(&ax12, settingsActionneurs.AX12_angle_recuperation);
	pompeEnable(&Pompe1);
	ascenseur_setPosition(settingsActionneurs.ASC_hauteur_recuperation);
	while(ascenseur.position!=ascenseur.position_souhaitee){/*Do nothing*/}
	//L'hexagone est au bout du bras maintenant
	if(demandeRecue.keep==1){
		ascenseur_setPosition(settingsActionneurs.ASC_hauteur_depot);
		while(ascenseur.position!=ascenseur.position_souhaitee){/*Do nothing*/}
		AX12_setPosition(&ax12, settingsActionneurs.AX12_angle_depot);
	}
	else{
		ascenseur_setPosition(settingsActionneurs.ASC_hauteur_depot+20);
		while(ascenseur.position!=ascenseur.position_souhaitee){/*Do nothing*/}
		AX12_setPosition(&ax12, settingsActionneurs.AX12_angle_depot);
		tiroirOuvrir(&MccUsed);
		ascenseur_setPosition(settingsActionneurs.ASC_hauteur_depot);
		while(ascenseur.position!=ascenseur.position_souhaitee){/*Do nothing*/}
		pompeDisable(&Pompe1);
		//L'hexagone n'est plus rattaché au bras
		if((demandeRecue.reverse==1 && settingsActionneurs.casier_concerned>=2 && settingsActionneurs.casier_concerned<=4)||settingsActionneurs.casier_concerned>=5)
		{
			ascenseur_setPosition(settingsActionneurs.ASC_hauteur_depot-20);
			while(ascenseur.position!=ascenseur.position_souhaitee){/*Do nothing*/}
		}
		else{
			ascenseur_setPosition(settingsActionneurs.ASC_hauteur_depot+20);
			while(ascenseur.position!=ascenseur.position_souhaitee){/*Do nothing*/}
		}
		tiroirFermer(&MccUsed);
	}
}


void mvt_deroulement_destockage(){
	if(demandeRecue.keep==1){/*Ne rien faire*/}
	else{
		if(settingsActionneurs.casier_concerned>=5){
			ascenseur_setPosition(settingsActionneurs.ASC_hauteur_depot-20);
			while(ascenseur.position!=ascenseur.position_souhaitee){/*Do nothing*/}
		}
		else{
			ascenseur_setPosition(settingsActionneurs.ASC_hauteur_depot+20);
			while(ascenseur.position!=ascenseur.position_souhaitee){/*Do nothing*/}
		}
		AX12_setPosition(&ax12, settingsActionneurs.AX12_angle_recuperation);
		while(ascenseur.position!=ascenseur.position_souhaitee){/*Do nothing*/}
		pompeEnable(&Pompe1);
		tiroirOuvrir(&MccUsed);
		ascenseur_setPosition(settingsActionneurs.ASC_hauteur_depot);
		while(ascenseur.position!=ascenseur.position_souhaitee){/*Do nothing*/}
		//L'hexagone est accroché au bout du bras
		ascenseur_setPosition(settingsActionneurs.ASC_hauteur_depot+20);
		while(ascenseur.position!=ascenseur.position_souhaitee){/*Do nothing*/}
		tiroirFermer(&MccUsed);
	}
	AX12_setPosition(&ax12, settingsActionneurs.AX12_angle_depot);
	while(ascenseur.position!=ascenseur.position_souhaitee){/*Do nothing*/}
	ascenseur_setPosition(settingsActionneurs.ASC_hauteur_depot);
	pompeDisable(&Pompe1);
	//L'hexagone n'est plus attaché au bras
	ascenseur_setPosition(settingsActionneurs.ASC_hauteur_depot+50);
	while(ascenseur.position!=ascenseur.position_souhaitee){/*Do nothing*/}
}











