/*
 * tiroirs.h
 *
 *  Created on: Feb 21, 2022
 *      Author: Sébastien BOHN
 */

#ifndef INC_TIROIRS_H_
#define INC_TIROIRS_H_

#include "main.h"
#include "Config_Phobos.h"

//Définition d'une structure pour les moteurs MCC des tiroirs
typedef struct
{
	GPIO_TypeDef* Input1_Port;     	/* Spécifie le port pour le GPIO relié au Input1 du L293D */
	uint32_t Input1_Pin;      	   	/* Spécifie le pin pour le GPIO relié au Input1 du L293D */
	GPIO_TypeDef* Input2_Port;    	/* Spécifie le port pour le GPIO relié au Input2 du L293D */
	uint32_t Input2_Pin;      		/* Spécifie le pin pour le GPIO relié au Input2 du L293D */
	GPIO_TypeDef* Enable_Port;     	/* Spécifie le port pour le GPIO relié au Enable du L293D */
	uint32_t Enable_Pin;      		/* Spécifie le pin pour le GPIO relié au Enable du L293D */
	uint8_t etat; 					/* Etat du casiers : 0=vide, 1=occupé */
	uint8_t color;					/* Si occupé, définit la couleur de l'hexagone qu'il contient */
	uint8_t identifier;				/* Numéro d'identification du casier */
}MccTiroir_InitTypeDef;


//Fonctions créées
void tiroir_Init(MccTiroir_InitTypeDef*, uint8_t, GPIO_TypeDef*, uint32_t,
		GPIO_TypeDef*, uint32_t, GPIO_TypeDef*, uint32_t);
void tiroirs_Init_All(void);
void tiroirArret(MccTiroir_InitTypeDef*);
void tiroirArretAll();
void tiroirOuvrir(MccTiroir_InitTypeDef*);
void tiroirFermer(MccTiroir_InitTypeDef*);
void tiroirEnable(MccTiroir_InitTypeDef*);
void tiroirEnableAll();
void tiroirDisable(MccTiroir_InitTypeDef*);
void tiroirDisableAll();
void tiroirSetEmpty(MccTiroir_InitTypeDef*);
void tiroirSetOccupied(MccTiroir_InitTypeDef*, uint8_t);
uint8_t tiroirSearchAvailable(uint8_t);
uint8_t tiroirSearchSpecificColor(uint8_t);
void tiroirSetUsed(void);

#endif /* INC_TIROIRS_H_ */

