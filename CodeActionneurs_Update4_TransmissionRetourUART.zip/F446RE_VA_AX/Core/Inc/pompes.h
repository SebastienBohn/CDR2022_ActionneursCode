/*
 * pompes.h
 *
 *  Created on: Mar 07, 2022
 *      Author: Sébastien BOHN
 */

#ifndef INC_POMPES_H_
#define INC_POMPES_H_

#include "main.h"

//Définition d'une structure pour les moteurs MCC des tiroirs
typedef struct
{
	GPIO_TypeDef* Pompe_Enable_Port;     /* Spécifie le port pour le GPIO relié au signal Enable qui part vers une pompe */
	uint32_t Pompe_Enable_Pin;      /* Spécifie le pin pour le GPIO relié au signal Enable qui part vers une pompe */
}Pompe_InitTypeDef;


//Fonctions créées
void pompes_Init(void);
void pompeEnable(Pompe_InitTypeDef* Pompe);
void pompeDisable(Pompe_InitTypeDef* Pompe);


#endif /* INC_POMPES_H_ */

