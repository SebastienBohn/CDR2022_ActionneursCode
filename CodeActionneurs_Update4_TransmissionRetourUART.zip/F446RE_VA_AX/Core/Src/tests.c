/*
 * File created by Sébastien BOHN
 * For Ares-CDR2022
 * On 05/05/2022
 */

#include "tests.h"

extern MccTiroir_InitTypeDef Mcc1;
extern MccTiroir_InitTypeDef Mcc2;
extern MccTiroir_InitTypeDef Mcc3;
extern MccTiroir_InitTypeDef Mcc4;
extern MccTiroir_InitTypeDef Mcc5;
extern MccTiroir_InitTypeDef Mcc6;

void Test_1() //Teste le temps que met un casier à sortir
{
	//tiroirs_Init();
	tiroirEnable(&Mcc1);
	tiroirOuvrir(&Mcc1);
	while(HAL_GPIO_ReadPin(SWITCH_AV_GPIO_Port, SWITCH_AV_Pin)!=1){}
	tiroirArret(&Mcc1);
}


void Test_2() //Teste le temps que met un casier à rentrer
{
	//tiroirs_Init();
	tiroirEnable(&Mcc1);
	tiroirFermer(&Mcc1);
	while(HAL_GPIO_ReadPin(SWITCH_AR_GPIO_Port, SWITCH_AR_Pin)!=1){}
	tiroirArret(&Mcc1);
}

void Test_3()
{

}
