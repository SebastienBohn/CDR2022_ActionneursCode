/*
 * File created by Sébastien BOHN
 * For Ares-CDR2022
 * On 08/05/2022
 */

#include "Config_Phobos.h"


Demande_recue demandeRecue = {0};
Settings_Actionneurs settingsActionneurs = {0};
extern uint8_t ReceivedData;
extern Ascenseur ascenseur;


//Fonction principale, lancée par l'interruption et la réception d'une donnée sur l'UART2
void configMainFunction(){
	configSetStructParameters();
	configSetActionneurCasier();
	configSetActionneurAX12();
	configSetActionneurAscenseur();
	mvtMainFunction();
}


void configSetStructParameters()
{
	demandeRecue.state = (ReceivedData & 0b10000000)>>7;
	demandeRecue.place = ((ReceivedData & 0b100000)>>4) + ((ReceivedData & 0b10000)>>4);
	demandeRecue.keep = (ReceivedData & 0b1000)>>3;
	demandeRecue.reverse = (ReceivedData & 0b100)>>2;
	demandeRecue.color = (ReceivedData & 0b10) + (ReceivedData & 0b1);
}


//Réglages concernant le casier concerné
void configSetActionneurCasier(){
	if(demandeRecue.state==0 && demandeRecue.keep==0){
		settingsActionneurs.casier_concerned = tiroirSearchAvailable(demandeRecue.reverse);
	}
	else if(demandeRecue.state==0 && demandeRecue.keep==1){
		settingsActionneurs.casier_concerned=0;
	}
	else if(demandeRecue.state==1){
		settingsActionneurs.casier_concerned = tiroirSearchSpecificColor(demandeRecue.color);
		//Protection en cas de mauvais code envoyé, ne devrait jamais arriver
		while(settingsActionneurs.casier_concerned==0){
			//On rend un hexagone de n'importe quelle couleur
			settingsActionneurs.casier_concerned = tiroirSearchSpecificColor((demandeRecue.color+1)%4);
		}
	}
}


//Réglages concernant l'angle de l'AX12
void configSetActionneurAX12(){
	if(demandeRecue.state==0){//On veut déposer un hexagone dans un casier
		switch(demandeRecue.place){
		case 0:
			settingsActionneurs.AX12_angle_recuperation = ANGLE_MIN;
			break;
		case 1:
			settingsActionneurs.AX12_angle_recuperation = ANGLE_MUSEE;
			break;
		case 2:
			settingsActionneurs.AX12_angle_recuperation = ANGLE_BAC_ECHANTILLON;
			break;
		case 3:
			settingsActionneurs.AX12_angle_recuperation = ANGLE_MIN;
			break;
		default :
			break;
		}
		if(demandeRecue.keep==1)
			settingsActionneurs.AX12_angle_depot = ANGLE_DROIT;
		else{
			if((demandeRecue.reverse==1 && settingsActionneurs.casier_concerned>=2 && settingsActionneurs.casier_concerned<=4)||settingsActionneurs.casier_concerned>=5)
				settingsActionneurs.AX12_angle_depot = ANGLE_MAX; //On dépose par le dessous
			else
				settingsActionneurs.AX12_angle_depot = ANGLE_MIN; //On dépose par le dessus
		}
	}
	else{ //On veut déstocker un hexagone
		switch(demandeRecue.place){
		case 0:
			settingsActionneurs.AX12_angle_depot = ANGLE_MIN;
			break;
		case 1:
			settingsActionneurs.AX12_angle_depot = ANGLE_MUSEE;
			break;
		case 2:
			settingsActionneurs.AX12_angle_depot = ANGLE_BAC_ECHANTILLON;
			break;
		case 3:
			settingsActionneurs.AX12_angle_depot = ANGLE_MIN;
			break;
		default :
			break;
		}
		if(demandeRecue.keep==1)
			settingsActionneurs.AX12_angle_recuperation = ANGLE_DROIT;
		else{
			if(settingsActionneurs.casier_concerned>=5)
				settingsActionneurs.AX12_angle_recuperation = ANGLE_MAX;
			else
				settingsActionneurs.AX12_angle_recuperation = ANGLE_MIN;
		}
	}
}


//Réglages concernant la hauteur de l'ascenseur
void configSetActionneurAscenseur(){
	if(demandeRecue.state==0){//On veut déposer un hexagone dans un casier
		switch(demandeRecue.place){
		case 0:
			settingsActionneurs.ASC_hauteur_recuperation = ASC_LVL_SOL;
			break;
		case 1:
			settingsActionneurs.ASC_hauteur_recuperation = ASC_LVL_MUSEE;
			break;
		case 2:
			settingsActionneurs.ASC_hauteur_recuperation = ASC_LVL_BAC_ECHANTILLON;
			break;
		case 3:
			settingsActionneurs.ASC_hauteur_recuperation = ASC_LVL_SUPPORT_ECHANTILLON_HAUT_PLAT;
			break;
		default :
			break;
		}
		if(demandeRecue.keep==1)
			settingsActionneurs.ASC_hauteur_depot = ASC_LVL_KEEP;
		else{
			switch(settingsActionneurs.casier_concerned){
			case 1:
				settingsActionneurs.ASC_hauteur_depot = ASC_LVL_C1_HAUT;
				break;
			case 2:
				if(demandeRecue.reverse==1)
					settingsActionneurs.ASC_hauteur_depot = ASC_LVL_C2_BAS;
				else
					settingsActionneurs.ASC_hauteur_depot = ASC_LVL_C2_HAUT;
				break;
			case 3:
				if(demandeRecue.reverse==1)
					settingsActionneurs.ASC_hauteur_depot = ASC_LVL_C3_BAS;
				else
					settingsActionneurs.ASC_hauteur_depot = ASC_LVL_C3_HAUT;
				break;
			case 4:
				if(demandeRecue.reverse==1)
					settingsActionneurs.ASC_hauteur_depot = ASC_LVL_C4_BAS;
				else
					settingsActionneurs.ASC_hauteur_depot = ASC_LVL_C4_HAUT;
				break;
			case 5:
				settingsActionneurs.ASC_hauteur_depot = ASC_LVL_C5_BAS;
				break;
			case 6:
				settingsActionneurs.ASC_hauteur_depot = ASC_LVL_C6_BAS;
				break;
			default:
				break;
			}
		}
	}
	else{//On veut déstocker un hexagone
		if(demandeRecue.keep==1)
			settingsActionneurs.ASC_hauteur_recuperation = ASC_LVL_KEEP;
		else{
			switch(settingsActionneurs.casier_concerned){
			case 1:
				settingsActionneurs.ASC_hauteur_recuperation = ASC_LVL_C1_HAUT;
				break;
			case 2:
				settingsActionneurs.ASC_hauteur_recuperation = ASC_LVL_C2_HAUT;
				break;
			case 3:
				settingsActionneurs.ASC_hauteur_recuperation = ASC_LVL_C3_HAUT;
				break;
			case 4:
				settingsActionneurs.ASC_hauteur_recuperation = ASC_LVL_C4_HAUT;
				break;
			case 5:
				settingsActionneurs.ASC_hauteur_recuperation = ASC_LVL_C5_BAS;
				break;
			case 6:
				settingsActionneurs.ASC_hauteur_recuperation = ASC_LVL_C6_BAS;
				break;
			default:
				break;
			}
		}
		switch(demandeRecue.place){
		case 0:
			settingsActionneurs.ASC_hauteur_depot = ASC_LVL_SOL;
			break;
		case 1:
			settingsActionneurs.ASC_hauteur_depot = ASC_LVL_MUSEE;
			break;
		case 2:
			settingsActionneurs.ASC_hauteur_depot = ASC_LVL_BAC_ECHANTILLON;
			break;
		case 3:
			settingsActionneurs.ASC_hauteur_depot = ASC_LVL_SUPPORT_ECHANTILLON_HAUT_PLAT;
			break;
		default :
			break;
		}
	}
}




