/*
 * Fichier créé par Sébastien BOHN pour Ares
 * Le 08/03/2022
 */


/* Includes ------------------------------------------------------------------*/
#include "ascenseur.h"
#include <math.h>

/*Variables globales ---------------------------------------------------------*/
Stepper stepperAscenseur;
Ascenseur ascenseur = {0};
AX12 ax12;


void ascenseur_AX12_init(){
	AX12_Init(&ax12, &huart3, 4, BR_250K);
	AX12_pingModule(&ax12);
	AX12_LED_O_N(&ax12, 1);
	AX12_setMovingSpeed(&ax12, 10);
	AX12_setRangeAngle(&ax12, ANGLE_MIN, ANGLE_MAX);
}





void ascenseur_init() {
	drv8825_init(
			&stepperAscenseur,
			DRV_EN_Pin, DRV_EN_GPIO_Port,
			DRV_DIR_Pin, DRV_DIR_GPIO_Port,
			&htim14, TIM_CHANNEL_1
	);
	ascenseur.position = 0;
	ascenseur.speed = 0;
	ascenseur.position_souhaitee = 0;
}


void ascenseur_enableMotor() {
	drv8825_enable(&stepperAscenseur);
}

void ascenseur_disableMotor() {
	drv8825_disable(&stepperAscenseur);
}

void ascenseur_setSpeed(float vitesse) {
	ascenseur.speed = vitesse;
	drv8825_setDirection(&stepperAscenseur, (vitesse < 0)?NEGATIVE:POSITIVE);
	drv8825_setRotationSpeed(&stepperAscenseur, 60 * fabsf(vitesse) / (2*M_PI*POULIE_RADIUS));
	//drv8825_setRotationSpeed(&stepperAscenseur, fabsf(vitesse)*2*M_PI*POULIE_RADIUS/60);
}

// float dt est en secondes
void ascenseur_updatePosition(float dt) {
	ascenseur.position += ascenseur.speed * dt;
}

/**
 * @param position : valeur en mm
 */
void ascenseur_setPosition(float position){
	ascenseur.position_souhaitee = position;
}



