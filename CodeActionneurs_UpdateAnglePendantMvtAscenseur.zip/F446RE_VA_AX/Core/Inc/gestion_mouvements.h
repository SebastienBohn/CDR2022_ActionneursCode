/*
 * gestion_mouvements.h
 *
 *  Created on: Mai 11, 2022
 *      Author: Sébastien BOHN
 */

#ifndef INC_GESTION_MOUVEMENTS_H_
#define INC_GESTION_MOUVEMENTS_H_

#include "main.h"
#include "Config_Phobos.h"
#include "pompes.h"
#include "AX12.h"
#include "ascenseur.h"


//Définition des fonctions utilisées
void mvtMainFunction(void);
void mvt_deroulement_stockage(void);
void mvt_deroulement_destockage(void);


#endif /* INC_GESTION_MOUVEMENTS_H_ */
