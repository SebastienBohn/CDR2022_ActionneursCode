/*
 * tests.h
 *
 *  Created on: Mai 05, 2022
 *      Author: Sébastien BOHN
 */

#ifndef INC_TESTS_H_
#define INC_TESTS_H_

#include "main.h"
#include "tiroirs.h"

void Test_1(void);
void Test_2(void);






















#endif /* INC_TESTS_H_ */
